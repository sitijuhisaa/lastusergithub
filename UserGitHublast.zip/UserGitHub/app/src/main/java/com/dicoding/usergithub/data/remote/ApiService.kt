package com.dicoding.usergithub.data.remote

import com.dicoding.usergithub.data.model.DetailUser
import com.dicoding.usergithub.data.model.ItemsItem
import com.dicoding.usergithub.data.model.UserResponse
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.QueryMap

interface ApiService {
    @JvmSuppressWildcards
    @Headers("Authorization: token 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")
    @GET("users")
    suspend fun getUser(): MutableList<ItemsItem>

    @JvmSuppressWildcards
    @Headers("Authorization: token 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")
    @GET("users/{username}")
    suspend fun getDetailUser(@Path("username")username: String): DetailUser

    @JvmSuppressWildcards
    @Headers("Authorization: token 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")
    @GET("users/{username}/followers")
    suspend fun getFollowers(@Path("username")username: String): MutableList<ItemsItem>

    @JvmSuppressWildcards
    @Headers("Authorization: token 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")
    @GET("users/{username}/following")
    suspend fun getFollowing(@Path("username")username: String): MutableList<ItemsItem>

    @JvmSuppressWildcards
    @Headers("Authorization: token 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")
    @GET("search/users")
    suspend fun getSearch(@QueryMap params: Map<String, Any>): UserResponse
}